<?php
$servername = "localhost";
$username = "root";
$password = "steven123";
$dbname = "steden";